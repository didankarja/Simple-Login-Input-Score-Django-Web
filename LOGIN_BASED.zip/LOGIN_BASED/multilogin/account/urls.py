from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name= 'index'),
    path('login/', views.login_view, name='login_view'),
    path('register/', views.register, name='register'),
    path('adminpage/', views.admin, name='adminpage'),
    path('student/scorestudent/', views.scorestudent, name='scorestudent'),
    path('student/', views.student, name='student'),
    path('teacher/', views.teacher, name='teacher'),
    path('teacher/input/', views.input_blog, name='input-blog'),
    path('score/', views.score_blog, name='score-blog'), 
    path('delete/<int:pk>', views.delete_blog, name='delete-blog'),

]