from django.db import models
from django.contrib.auth.models import AbstractUser

# Create your models here.


class User(AbstractUser):
    is_admin= models.BooleanField('Is admin', default=False)
    is_student = models.BooleanField('Is customer', default=False)
    is_teacher = models.BooleanField('Is employee', default=False)

class Blog(models.Model):
    Student_Name = models.CharField(max_length=500)
    Course = models.CharField(max_length=200)
    Score = models.CharField(max_length=300)
    Input_Date = models.DateField()

    class Meta:
        db_table = 'Blog'